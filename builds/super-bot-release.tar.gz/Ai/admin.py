"""Independent keyboard administration dashboard, with plain-terminal fallback."""
import concurrent.futures
import json
import os
import shlex
import sys
import time
from Ai import tui
from Ai.manager_cli import execute, parser, snapshot, logs

ACTIONS = [('Status', 'status'), ('Start', 'start'), ('Stop', 'stop'), ('Restart', 'restart'),
           ('Check updates', 'update check'), ('Apply cached update', 'update apply --offline'),
           ('Rollback', 'update rollback'), ('Sources', 'source list'), ('Configuration', 'config')]


def action(text, runtime, releases):
    args = parser().parse_args(shlex.split(text))
    if args.command == 'remote':
        import subprocess
        from Ai.manager_cli import remote_command
        result = subprocess.run(remote_command(args.host, args.action), capture_output=True, text=True, timeout=600)
        return {'exit_code': result.returncode, 'output': result.stdout, 'diagnostic': result.stderr}
    if args.command == 'admin' or (args.command == 'start' and args.foreground):
        raise ValueError('Use the shell for remote actions and foreground mode.')
    return execute(args, runtime, releases)


def lines_for(state):
    server = state['server']
    return ['Super Bot administration',
            f"Server: {server['state']}   Version: {state['release']['version']}",
            f"Source: {state['source']['kind']} / {state['source']['channel']}",
            f"Clients: {server.get('clients', '-')}   Sessions: {server.get('sessions', '-')}",
            f"Instance: {state['instance']}"]


def run(args, runtime, releases):
    if args.once or not sys.stdin.isatty() or not sys.stdout.isatty():
        print(json.dumps(snapshot(runtime, releases), indent=2))
        return 0
    if args.plain or os.getenv('TERM') == 'dumb':
        return plain(runtime, releases)
    try:
        import curses
    except ImportError:
        return plain(runtime, releases)
    try:
        return curses.wrapper(screen, runtime, releases)
    except curses.error:
        return plain(runtime, releases)


def plain(runtime, releases):
    while True:
        print('\n'.join(lines_for(snapshot(runtime, releases))))
        print(' | '.join(f'{i+1} {label}' for i, (label, _) in enumerate(ACTIONS)))
        print('Enter a number, a manager command (including source use), or q. Remote: use SSH in your shell.')
        try:
            value = input('admin> ').strip()
        except EOFError:
            return 0
        if value in ('q', 'quit'):
            return 0
        if value.isdigit() and 1 <= int(value) <= len(ACTIONS):
            value = ACTIONS[int(value)-1][1]
        try:
            print(json.dumps(action(value, runtime, releases), indent=2))
        except (Exception, SystemExit) as exc:
            print(f'Action failed: {exc}')


def screen(window, runtime, releases):
    import curses
    window.keypad(True)
    window.timeout(200)
    selected, output, command = 0, [], None
    future = None
    last = 0
    state = snapshot(runtime, releases)
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        while True:
            now = time.monotonic()
            if future and future.done():
                try:
                    output = json.dumps(future.result(), indent=2).splitlines()
                except (Exception, SystemExit) as exc:
                    output = [f'Action failed: {exc}']
                future = None
                last = 0
            if now - last > 2 and not future:
                state = snapshot(runtime, releases)
                last = now
            height, width = window.getmaxyx()
            window.erase()
            rows = lines_for(state)
            visible = max(1, height - 10)
            first = max(0, selected - visible + 1)
            rows += [f'{">" if i == selected else " "} {label}' for i, (label, _) in enumerate(ACTIONS) if first <= i < first + visible]
            rows += ['Working...' if future else 'Result / live server log:']
            rows += (output[-6:] if output else logs(runtime, 6).splitlines())
            for y, row in enumerate(rows[:max(0, height-2)]):
                try:
                    window.addstr(y, 0, tui.clip(row, max(0, width-1)), curses.A_BOLD if y == 0 else 0)
                except curses.error:
                    pass
            footer = ':' + command if command is not None else 'Up/Down select | Enter run | : command | l logs | q quit'
            if height > 1:
                try:
                    window.addstr(height-1, 0, tui.clip(footer, max(0, width-1)), curses.A_REVERSE)
                except curses.error:
                    pass
            window.refresh()
            key = window.getch()
            if command is not None:
                if key == 27:
                    command = None
                elif key in (10, 13) and not future:
                    future = executor.submit(action, command, runtime, releases)
                    command = None
                elif key in (curses.KEY_BACKSPACE, 127, 8):
                    command = command[:-1]
                elif 32 <= key < 127:
                    command += chr(key)
                continue
            if key in (ord('q'), 27) and not future:
                return 0
            if key in (curses.KEY_DOWN, ord('j')):
                selected = (selected+1) % len(ACTIONS)
            elif key in (curses.KEY_UP, ord('k')):
                selected = (selected-1) % len(ACTIONS)
            elif key in (10, 13) and not future:
                future = executor.submit(action, ACTIONS[selected][1], runtime, releases)
            elif key == ord(':'):
                command = ''
            elif key == ord('l'):
                output = []
